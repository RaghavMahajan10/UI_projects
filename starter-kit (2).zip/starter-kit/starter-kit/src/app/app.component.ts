/// <reference types="ids-enterprise-typings" />
import {
  Component,
  HostBinding,
  ViewEncapsulation,
  ViewChild,
  AfterViewInit
} from '@angular/core';


import { ApiTokenService } from './services/apitoken.service';
import { Router } from '@angular/router';
@Component({
  selector: 'body', // eslint-disable-line
   standalone: false,
  templateUrl: 'app.component.html',
  styleUrls: [ './app.component.css' ],
  encapsulation: ViewEncapsulation.Emulated
})
export class AppComponent implements AfterViewInit {

  /**
   * Local Storage Key
   */
  private static isMenuOpen = 'is-application-menu-open';
loading = true;
  @HostBinding('class.no-scroll') get isNoScroll() { return true; }

  /**
   * Include the new icons only if required by the current theme, this
   * is not quite perfect, as we need to listen for the theme change here.
   * Maybe wrap all the icons into their own component?
   */
  public useNewIcons = false;

  public personalizeOptions: SohoPersonalizeOptions = {};

  constructor( private apiTokenService: ApiTokenService,private router:Router) {
    // Init render loop manually for Angular applications
    // Ensures requestAnimationFrame is running outside of Angular Zone
    
    // const token = this.appService.getTokenData('');
    // if (!token) {
    //   this.apiTokenService.getAPIToken();
    // }
  }

  ngAfterViewInit(): void {
    //this.router.navigate(["data"], { skipLocationChange: true });
    /**
     * Note: If using an input like [triggers]="[ '.application-menu-trigger' ]"
     * hookup the app menu trigger once the afterViewInit is called. This will
     * ensure that the toolbar has had a chance to create the application-menu-trugger
     * button.
     * this.applicationMenu.triggers = [ '.application-menu-trigger' ];
     */
    
  }

  public get isApplicationMenuOpen(): boolean {
    const valueString = localStorage.getItem(AppComponent.isMenuOpen);
    return valueString ? (valueString === 'true') : true;
  }

  public set isApplicationMenuOpen(open: boolean) {
    localStorage.setItem(AppComponent.isMenuOpen, open ? 'true' : 'false');
  }

  onChangeTheme(ev: SohoPersonalizeEvent) {
    this.useNewIcons = ev.data.theme === 'theme-uplift-light'
      || ev.data.theme === 'theme-uplift-dark'
      || ev.data.theme === 'theme-uplift-contrast'
      || ev.data.theme === 'theme-new-light'
      || ev.data.theme === 'theme-new-dark'
      || ev.data.theme === 'theme-new-contrast';
  }

  public onMenuVisibility(visible: boolean): void {
    if (this.isApplicationMenuOpen !== visible) {
      this.isApplicationMenuOpen = visible;
    }
  }
}
