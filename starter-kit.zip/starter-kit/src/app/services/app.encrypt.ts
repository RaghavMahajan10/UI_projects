import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';

// import * as cryptoJS from 'crypto-js';
// import * as cryptoJS from 'crypto-js';




@Injectable()
export class AppEncrypt {
    

        // secretKey = environment.encryptkey;
        // constructor() { }
      
        // public encrypt(value : string) : string{
        //   // return cryptoJS.AES.encrypt(value, this.secretKey.trim()).toString();
        //   return value;
        // }
        
        // public decrypt(textToDecrypt : string){
        //   // return cryptoJS.AES.decrypt(textToDecrypt, this.secretKey.trim()).toString(cryptoJS.enc.Utf8);
        //   return textToDecrypt;
        // }
      }