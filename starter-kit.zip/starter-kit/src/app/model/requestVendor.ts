export interface RequestVendor {
    request_vendor: string;
    
}