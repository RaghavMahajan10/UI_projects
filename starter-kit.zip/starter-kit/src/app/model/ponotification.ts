export interface PONotifications {
  updateType: string;
  recId: string;
  userId: string;
  requestVendor: string;
  requestVendorEmail: string;
  requestRegion: string;
}